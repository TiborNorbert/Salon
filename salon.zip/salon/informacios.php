<?php
include 'minden/header.php';
$sql1="SELECT `nev`,`email` FROM `dolgozo` WHERE `szolgaltasid`='1';";
$result1=$db->RunSQL($sql1);
$sql2="SELECT `nev`,`email` FROM `dolgozo` WHERE `szolgaltasid`='2';";
$result2=$db->RunSQL($sql2);
$sql3="SELECT `nev`,`email` FROM `dolgozo` WHERE `szolgaltasid`='3';";
$result3=$db->RunSQL($sql3);
$sql4="SELECT `nev`,`email` FROM `dolgozo` WHERE `szolgaltasid`='4';";
$result4=$db->RunSQL($sql4);
?>
<style>
    h1,
    h2{
        text-align: center;
        font-size: 20px;
        text-decoration: underline;
    }
    h3,
    p {
        text-align: center;
        font-size: 30px;
    }
    .mail{
        color:#5C4033;
        text-align: center;
        font-size: 15px;
    }
  </style>  
<div class="info">
    <h1>Információk</h1>
    <h2>Elérhetőségek</h2>
    <p><icon>Tel:+36202211144</p>
    <p>Email: levai.tibor.norbert@dszcberegszaszi.hu</p>
    <h2>Tudnivalók</h2>
    <h3>Fodrász</h3>
    <?php foreach ($result1 as $sor1):?>                
        <p><?php echo $sor1['nev']?> <div class="mail"><?php echo $sor1['email']?></div> </p> 
               <?php endforeach;?>
        <h3>Manikűr és mükörmös</h3>
        <?php foreach ($result2 as $sor2):?>                
        <p><?php echo $sor2['nev']?> <div class="mail"><?php echo $sor2['email']?></div></p> 
                <?php endforeach;?>
        <h3>Kozmetikus</h3>
        <?php foreach ($result3 as $sor3):?>                
        <p><?php echo $sor3['nev']?> <div class="mail"><?php echo $sor3['email']?></div></p>
                <?php endforeach;?>
        <h3>Masszőr</h3>
        <?php foreach ($result4 as $sor4):?>                
        <p><?php echo $sor4['nev']?> <div class="mail"><?php echo $sor4['email']?></div></p>
                <?php endforeach;?>
</div>