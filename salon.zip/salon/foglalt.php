<?php
include 'minden/header.php';
$nev = $db->sanitizeData($_SESSION['nev']);
$sql = "SELECT szolgaltatasok.szolgaltatas,szolgaltatasok.ar,dolgozo.nev,foglalas.datum from vevo inner join foglalas on vevo.vevoid=foglalas.vevoid inner join dolgozo on foglalas.dolgozoid=dolgozo.dolgozoid inner join szolgaltatasok on dolgozo.szolgaltasid=szolgaltatasok.szid Where vevo.nev='$nev';";
$result = $db->RunSQL($sql);
$result2 = $db->RunSQL($sql);
$result3 = $db->RunSQL($sql);
$result4 = $db->RunSQL($sql);
$foglalt = $result->fetch_assoc()['szolgaltatas'];
$foglalt2 = $result2->fetch_assoc()['ar'];
$foglalt3 = $result3->fetch_assoc()['nev'];
$foglalt4 = $result4->fetch_assoc()['datum'];
?>
<style>
        .design{
        text-align: center;
        font-size: 30px;
        border:2px solid ;
        background-color:rgb(255,255,255,0.5);
    }
</style>
<main>
    <div class="container">
        <h1>Ídőpont Megtekintése</h1>
        <div class="data">
            <div class="design"><?php
            echo $foglalt."<br />";
            ?></div>
            <div class="design"><?php
            echo $foglalt2."FT"."<br />";
            ?></div>
            <div class="design"><?php
            echo $foglalt3."<br />";
            ?></div>
            <div class="design"><?php
            echo $foglalt4."<br />";
            ?></div>
        </div>
    </div>
</main>
<?php
include 'minden/footer.php';
?>