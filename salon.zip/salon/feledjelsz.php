<?php
include 'minden/header.php';

if (isset($_POST['kuld'])) {
    $email = $db->sanitizeData($_POST['email']);
    $sql = "SELECT * FROM vevo WHERE email='$email';";
    echo $sql;
    $result = $db->RunSQl($sql);
    $nev = $result->fetch_assoc();

    if ($nev != false) {
        $to = $email;
        $subject = 'Elfelejtett jelszó';
        $message = '
	    Elfelejtett jelszó
        ------------------------
        Felhasználói név: ' . $nev['nev'] . '
        ------------------------
        Kérjük, kattintson erre a linkre új jelszó beállításához:
        http://localhost/zarodolgozat/newpassword.php?email=' . $email . '&hash=' . $nev['hash'];
        $headers = 'from:admin@localhost.org';
        mail($to, $subject, utf8_decode($message), $headers);
        echo '<div class="alert alert-success" role="alert">Az E-mailt elküldtük a megadott e-mail címedre</div>';
    } else {
        echo '<div class="alert alert-danger" role="alert">Az e-mail címhez nem található regisztráció </div>';
    }
}
?>
<div class="container">
    <main>
        <article class="d-flex flex-wrap" >
            <div class="col-6 offset-3 my-3">
                <div class="card mb-3 text-center h-100 mx-2">
                    <h1 class="my-3" >Elfelejtett jelszó</h1>
                    <div class="">
                        <form method="POST" >
                            <div class="data">
                                <label for="email" class="form-label">Kérjük adja meg az <strong>Email </strong> címét !</label>
                                <input type="email" class="form-control" id="email" name="email" >
                            </div>
                            <button type="submit" class="btn btn-secondary m-3" id="kuld" value="igen" name="kuld" >Elküld</button>
                            <div class="d-flex justify-content-around" >
                                <a style=" float:right; color:rgb(111, 78, 55)" href="login.php" >Bejelentkezés</a>
                            </div>


                        </form>
                    </div>

                </div>
            </div>

    </main>
</div>

<?php
include 'minden/footer.php';
?>
