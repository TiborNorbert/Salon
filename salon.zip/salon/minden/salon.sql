-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Gép: 127.0.0.1
-- Létrehozás ideje: 2023. Ápr 26. 15:39
-- Kiszolgáló verziója: 10.4.28-MariaDB
-- PHP verzió: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `salon`
--
CREATE DATABASE IF NOT EXISTS `salon` DEFAULT CHARACTER SET utf8 COLLATE utf8_hungarian_ci;
USE `salon`;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `dolgozo`
--

DROP TABLE IF EXISTS `dolgozo`;
CREATE TABLE `dolgozo` (
  `dolgozoid` int(16) NOT NULL,
  `nev` varchar(255) NOT NULL,
  `jelszo` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `szolgaltasid` int(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `dolgozo`
--

INSERT INTO `dolgozo` (`dolgozoid`, `nev`, `jelszo`, `email`, `szolgaltasid`) VALUES
(1, 'Nagy Zita', '2001', 'nagy.zita@gmail.com', 1),
(2, 'Gyöngy Géza', '2002', 'gyongy.geza@gmail.com', 1),
(3, 'Kerek Mária', '2003', 'kerek.maria@gmail.com', 2),
(4, 'Virag Adél', '2004', 'virag.adel@gmail.com', 2),
(5, 'Dávid János', '2005', 'david.janos@gmail.com', 2),
(6, 'Lente Boglárka', '2006', 'lente.boglarka@gmail.com', 3),
(7, 'Kiss Izabella', '2007', 'kiss.izabella@gmail.com', 3),
(8, 'Kis Virág', '2008', 'kis.virág@gmail.com', 4),
(9, 'Sárga Rózália', '2009', 'sarga.rozalia@gmail.com', 4);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `foglalas`
--

DROP TABLE IF EXISTS `foglalas`;
CREATE TABLE `foglalas` (
  `vevoid` int(11) NOT NULL,
  `szid` int(11) NOT NULL,
  `datum` datetime NOT NULL,
  `dolgozoid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `foglalas`
--

INSERT INTO `foglalas` (`vevoid`, `szid`, `datum`, `dolgozoid`) VALUES
(6, 2, '2020-02-02 20:20:00', 6),
(8, 4, '2020-02-02 20:20:00', 3),
(8, 11, '2023-04-24 07:20:00', 7);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `szolgaltatasok`
--

DROP TABLE IF EXISTS `szolgaltatasok`;
CREATE TABLE `szolgaltatasok` (
  `szid` int(2) NOT NULL,
  `nev` varchar(51) DEFAULT NULL,
  `ar` int(4) DEFAULT NULL,
  `szolgaltatas` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- A tábla adatainak kiíratása `szolgaltatasok`
--

INSERT INTO `szolgaltatasok` (`szid`, `nev`, `ar`, `szolgaltatas`) VALUES
(1, 'Arcmasszázs', 1500, 'masszazs'),
(2, 'Hátmasszázs', 1200, 'masszazs'),
(3, 'talpmasszázs', 1350, 'masszazs'),
(4, 'Nyirokmasszázs', 2000, 'masszazs'),
(5, 'Svéd masszázs', 2150, 'masszazs'),
(6, 'Alakformáló masszázs', 2500, 'masszazs'),
(7, 'férfi hajvágás', 2000, 'fodrasz'),
(8, 'női hajvágás', 2000, 'fodrasz'),
(9, 'hajszáritás', 700, 'fodrasz'),
(10, 'női hajfestés', 1700, 'fodrasz'),
(11, 'melir balayage', 2200, 'fodrasz'),
(12, 'dauer', 2400, 'fodrasz'),
(13, 'alkalmi fizurák', 2500, 'fodrasz'),
(14, 'gél lakk kézre', 1900, 'mukorom'),
(15, 'gél lakk lábra', 1850, 'mukorom'),
(16, 'zselés körömerősités', 1500, 'mukorom'),
(17, 'épitett zselé', 1500, 'mukorom'),
(18, 'francia diszites', 1500, 'mukorom'),
(19, 'manikűr', 1500, 'mukorom'),
(20, 'anyageltávolitás', 1500, 'mukorom'),
(21, 'anyageltávolitás manikűr', 1500, 'mukorom'),
(22, 'pótlás', 1500, 'mukorom'),
(23, 'extra diszités', 1500, 'mukorom'),
(24, 'szempilla festes', 1500, 'kozmetika'),
(25, 'szemöldök festés', 1500, 'kozmetika'),
(26, 'szemöldök szedés', 1500, 'kozmetika'),
(27, 'gyantázás bajusz', 1500, 'kozmetika'),
(28, 'gyantázás hónalj', 1500, 'kozmetika'),
(29, 'gyantázás kar', 1500, 'kozmetika'),
(30, 'gyantázás láb térdig', 1500, 'kozmetika'),
(31, 'gyantázás teljes láb', 1500, 'kozmetika'),
(32, 'gyantázás fazon', 1500, 'kozmetika'),
(33, 'gyantázás intim', 1500, 'kozmetika'),
(34, 'alap arctisztitás bőrtípusnak megfelelő termékekkel', 1500, 'kozmetika'),
(35, 'nappali smink', 1500, 'kozmetika'),
(36, 'nappali smink', 1501, 'kozmetika'),
(37, 'alkalmi smink', 1501, 'kozmetika');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `vevo`
--

DROP TABLE IF EXISTS `vevo`;
CREATE TABLE `vevo` (
  `vevoid` int(16) NOT NULL,
  `nev` text NOT NULL,
  `email` text NOT NULL,
  `jelszo` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `vevo`
--

INSERT INTO `vevo` (`vevoid`, `nev`, `email`, `jelszo`) VALUES
(6, 'asd1', 'asdd@gmail.com', '$2y$10$AvDUe2NO1cVzmaJDZS7uTe8HusTv8Rg7bivxVbAyGxRTuCNrigByG'),
(7, 'kispista', 'kis.pista@gmail.com', '$2y$10$OvYFRQcx3HSvGcSwbwoC6eznTXARGiKfy9hE7au4da9Ew0kyvDR6C'),
(8, 'asdasd', 'asdasd@gmail.com', '$2y$10$1txwrtNWwjO/KeSXwTL0ues/ahDZeHSAWHkr2EfCRmbzQ4nuqjNIC'),
(9, 'asd2', 'asd2@gmail.com', '$2y$10$pRw3ACTJccn/KZvZVdtOtOoXds352NCRssPIgAgDrDZfK1Qlsaw5y'),
(10, 'testt', 'testt@gmail.com', '$2y$10$G0.7AA256ugvvMiHTK0OXu4VQ.JFFaYa8un8jiRArPvNlSiHuAcX.');

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `dolgozo`
--
ALTER TABLE `dolgozo`
  ADD PRIMARY KEY (`dolgozoid`,`szolgaltasid`) USING BTREE,
  ADD KEY `szolgaltasid` (`szolgaltasid`);

--
-- A tábla indexei `foglalas`
--
ALTER TABLE `foglalas`
  ADD PRIMARY KEY (`vevoid`,`szid`,`dolgozoid`),
  ADD KEY `dolgozoid` (`dolgozoid`);

--
-- A tábla indexei `szolgaltatasok`
--
ALTER TABLE `szolgaltatasok`
  ADD PRIMARY KEY (`szid`);

--
-- A tábla indexei `vevo`
--
ALTER TABLE `vevo`
  ADD PRIMARY KEY (`vevoid`);

--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `dolgozo`
--
ALTER TABLE `dolgozo`
  MODIFY `dolgozoid` int(16) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT a táblához `vevo`
--
ALTER TABLE `vevo`
  MODIFY `vevoid` int(16) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Megkötések a kiírt táblákhoz
--

--
-- Megkötések a táblához `dolgozo`
--
ALTER TABLE `dolgozo`
  ADD CONSTRAINT `dolgozo_ibfk_1` FOREIGN KEY (`szolgaltasid`) REFERENCES `szolgaltatasok` (`szid`);

--
-- Megkötések a táblához `foglalas`
--
ALTER TABLE `foglalas`
  ADD CONSTRAINT `foglalas_ibfk_1` FOREIGN KEY (`vevoid`) REFERENCES `vevo` (`vevoid`),
  ADD CONSTRAINT `foglalas_ibfk_2` FOREIGN KEY (`dolgozoid`) REFERENCES `dolgozo` (`dolgozoid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
