<?php
include 'adatbazis.php';
$db = new Database();
session_start();
$sql = "SELECT DISTINCT szolgaltatas FROM szolgaltatasok;";
$result = $db->RunSQL($sql);
?>
<!DOCTYPE html>
<html lang="hu">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Szépség Salon</title>
    <link href="minden/style.css" rel="stylesheet" type="text/css" />
    <link href="minden/loginregister.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
    <header>
        <div class="navbar">
            <a href="index.php">Főoldal</a>
            <div class="dropdown">
                <button onclick="location.href = 'szolgaltatas.php'" type="button" class="dropbtn">Szolgáltatások</button>
            </div>
            <div class="dropdown">
                <button onclick="location.href = 'informacios.php'" type="button" class="dropbtn">Információk</button>
            </div>
            <div class="dropdown" style="float:right;">
                <?php if (isset($_SESSION['nev'])) : ?>
                    <a class="btn btn-outline-light ms-3" href="foglalas.php" role="button" class="dropbtn">Ídőpont Foglalás</a>
                    <a class="btn btn-outline-light ms-3" href="foglalt.php" role="button" class="dropbtn">Ídőpont Megtekintés</a>
                <a class="btn btn-outline-light ms-3" href="logout.php" role="button">Kijelentkezés(<?= $_SESSION['nev']; ?> )</a>
                <?php else: ?>
                <a class="btn btn-outline-light ms-3" href="login.php" role="button">Bejelentkezés</a>
                <?php endif; ?>
            </div>
        </div>
        </div>
    </header>