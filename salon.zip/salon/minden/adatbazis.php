<?php
class Database {
    private $database = 'salon';
    private $host = 'localhost';
    private $user = 'root';
    private $password = '';
    protected $dbc = null;
    public function __construct() {
        try {
            $this->dbc = new mysqli($this->host, $this->user, $this->password, $this->database);
            $this->dbc->set_charset('utf8');
        } catch (mysqli_sql_exception $exc) {
            echo "Kapcsolódási hiba:" . $exc->getMessage();
        }
    }

    public function RunSQL($sql) {
        try {
            $utasitas = $this->dbc->prepare($sql);
            $utasitas->execute();
        } catch (mysqli_sql_exception $exc) {
            echo "Lekérdezési hiba: " . $exc->getMessage();
        }
        $result = $utasitas->get_result();
        if ($result) {
            return $result;
        } else {
            return $utasitas->affected_rows;
        }
    }
    public function createHash($data) {
        return hash('sha512', $data . date("YYYY-mm-dd"));
    }

    public function sanitizeData($data) {
        return htmlspecialchars(trim($data));
    }
}
?>
