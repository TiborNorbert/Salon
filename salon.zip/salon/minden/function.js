function feloszt() {
    let pont = parseInt(document.getElementById("pontszam").value) % 5 + 1;
    
    switch (pont) {
        case 1:
            document.getElementById("erdemjegy").value = "elégtelen";
            break;
        case 2:
            document.getElementById("erdemjegy").value = "elégséges";
            break;
        case 3:
            document.getElementById("erdemjegy").value = "közepes";
            break;
        case 4:
            document.getElementById("erdemjegy").value = "jó";
            break;
        default:
            document.getElementById("erdemjegy").value = "jeles";
            break;
    }
}