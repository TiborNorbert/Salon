<?php
include 'minden/header.php';
?>
<style>
    h1{
        font-size: 160px;
        margin-top:180px;
        margin-right:125px ;
        margin-left: 180px;
        margin-bottom: 180px;
        border-radius: 2px;
        color:rgba(255, 255, 255, 0.5);
        -webkit-text-stroke:7px rgb(111, 78, 55);
    }
</style>
<main>
    <div class="alert alert-danger text-center" role="alert">
        <p style="text-align:center">A Időpont Foglaláshoz bejelentkezés szükséges</p>
    </div>
    <h1>Szépség Forrás Szalon</h1>
</main>
<?php
include 'minden/footer.php';
?>