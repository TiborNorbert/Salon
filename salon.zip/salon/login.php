<?php
include 'minden/header.php';
if (isset($_POST['login'])) {
  $email = $db->sanitizeData($_POST['email']);
  $jelszo = $db->sanitizeData($_POST['jelszo']);
  $GLOBALS['vevoid']=
  $sql = "SELECT * FROM vevo WHERE email = '$email';";
  $result = $db->RunSQL($sql);
  $nev = $result->fetch_assoc();

  if ($nev != false && password_verify( $jelszo, $nev['jelszo'])) {
      $_SESSION['email'] = $nev['email'];
      $_SESSION['nev'] = $nev['nev'];
      header('Location: foglalas.php');
  } else {
      echo '<div class="alert alert-danger text-center" role="alert">A Email cím '
      . ' és/vagy a jelszó nem megfelelő <br><strong>Próbálkozzon újra</strong></div>';
  }
}
?>
<script src="https://kit.fontawesome.com/a076d05399.js"></script>
</head>

<body>
  <div class="center">
    <label for="show" class="show-btn">Bejelentkezés</label>
    <div class="container">
      <a class="close-btn fas fa-times" title="close" href="index.php"></a>
      <div class="text">Bejelentkezés</div>
      <form method="POST">
        <div class="data">
          <label for="email">Email cím</label>
          <input type="email"  id="email" name="email" required>
        </div>
        <div class="data">
          <label for="jelszo">Jelszó</label>
          <input type="password" id="jelszo" name="jelszo" required>
        </div>
        <div class="forgot-pass">
          <a href="feledjelsz.php">Elfeledett Jelszó?</a></div>
        <div class="btn">
          <div class="inner">
          </div>
          <button type="submit" id="login" name="login">Bejelentkezés</button>
        </div>
        <div class="signup-link">Még nem regisztrált be? <a href="register.php">Regisztrálhat itt</a></div>
      </form>
    </div>
  </div>