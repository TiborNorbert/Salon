<?php
include 'minden/header.php';
$nev = $db->sanitizeData($_SESSION['nev']);
$sql1="SELECT `dolgozoid`,`nev` FROM `dolgozo`;";
$sql2="SELECT `szid`,`nev` FROM `szolgaltatasok`";
$result1=$db->RunSQL($sql1);
$result2=$db->RunSQL($sql2);
if (isset($_POST['foglal'])){
    $szid = $db->sanitizeData($_POST['szid']);
    $datum = $db->sanitizeData($_POST['datum']);
    $dolgozoid = $db->sanitizeData($_POST['dolgozoid']);
    if(empty($szid)){
        echo '<div class="alert alert-danger text-center" role="alert"> Nem választott szolgáltatást'
        . '<br><strong>Próbálkozzon újra</strong></div>';
    } else if(empty($dolgozoid)) {
        echo '<div class="alert alert-danger text-center" role="alert"> Nem választott dolgozott'
        . '<br><strong>Próbálkozzon újra</strong></div>';
    } else {
        $sql = "SELECT `vevoid` FROM vevo WHERE `nev` = '$nev';";
        $result = $db->RunSQL($sql);
        $vevoid = $result->fetch_assoc()['vevoid'];
        $sql3 = "INSERT INTO `foglalas`(`vevoid`, `szid`, `datum`, `dolgozoid`) VALUES ('$vevoid', '$szid', '$datum', '$dolgozoid')";
        $foglalas = $db->RunSQL($sql3);
        echo '<div class="alert alert-success text-center" role="alert"> Foglalás sikeres! '
        . '<br><strong>Köszönjük a foglalását!</strong></div>';}
        ?>
<script>
    setTimeout(() => {
        header("Location: foglalas.php");
        exit();
    }, 3000);
</script>
<?php
}
?>
<script src="https://kit.fontawesome.com/a076d05399.js"></script>
<div>
    <div class="container">
        <h1>Ídőpont Foglalás</h1><br>
        <form action="#" method="POST">
        <label class="data">Szolgáltatás</label>
        <select class="fog" name="szid">
                <?php foreach ($result2 as $sor2):?>
                <option name="szid" value="<?= $sor2['szid'];?>" ><?php echo $sor2['nev']?> </option>
                <?php endforeach;?>
            </select>
            <label class="data">Dolgozó</label>
        <select class="fog" name="dolgozoid">
                <?php foreach ($result1 as $sor1):?>                
                    <option name="dolgozoid" value="<?= $sor1['dolgozoid'];?>" ><?php echo $sor1['nev']?> </option>
                <?php endforeach;?>
            </select>
            <div class="fog">
                <input name="datum" type="datetime-local" value="2020-02-02T20:20" min="2000-06-07T00:00" max="2023-12-31T00:00"
                    pattern="[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}" required />
            </div>
            <div class="btn">
                <div class="inner">
                </div>
                <button type="submit" id="foglal" name="foglal">Foglalás</button>
            </div>
        </form>
    </div>
</div>