<?php
include 'minden/header.php';
if (isset($_POST['register'])) {
    $email = $db->sanitizeData($_POST['email']);
    $jelszo = password_hash($db->sanitizeData($_POST['jelszo']), PASSWORD_DEFAULT);
    $nev = $db->sanitizeData($_POST['nev']);

    $sql = "SELECT * FROM vevo WHERE email = '$email';";
    $result = $db->RunSQL($sql);
    $chk_email = $result->fetch_assoc();

    $sql = "SELECT * FROM vevo WHERE nev = '$nev';";
    $result = $db->RunSQL($sql);
    $chk_user = $result->fetch_assoc();

    if ($chk_email != false) {
        echo '<div class="alert alert-danger text-center" role="alert">Ezzel az email címmel már regisztráltak! <br><strong>Próbálkozzon újra</strong></div>';
    } elseif ($chk_user != false) {
        echo '<div class="alert alert-danger text-center" role="alert"> az email cím megfelelő, de az a felhasznaló név már foglalt '
        . '<br><strong>Próbálkozzon újra</strong></div>';
    } else {
        $hash = $db->createHash($nev);
        $sql = "INSERT INTO `vevo` VALUES ('null','$nev','$email','$jelszo');";
        $result = $db->RunSQL($sql);
        echo '<div class="alert alert-success text-center" role="alert"> A regisztráció sekeres! '
        . '<br><strong>Jelentkezz be!</strong></div>';
        ?>
        <script>
            setTimeout(() => {
                location.href = 'login.php';
            }, 3000);
        </script>

        <?php
    }
}
?>
<script src="https://kit.fontawesome.com/a076d05399.js"></script>
</head>

<body>
  <div class="center">
    <label for="show" class="show-btn">Regisztráció</label>
    <div class="container">
      <a class="close-btn fas fa-times" title="close" href="index.php"></a>
      <div class="text">Regisztráció</div>
      <form action="#" method="POST">
        <div class="data">
          <label for="nev">Név</label>
          <input type="text" id="nev" name="nev" required>
        </div>
        <div class="data">
          <label for="email">Email</label>
          <input type="email" id="email" name="email" required>
        </div>
        <div class="data">
          <label for="jelszo">Jelszó</label>
          <input type="password" id="jelszo" name="jelszo" required>
        </div>
        <div class="btn">
          <div class="inner">
          </div>
          <button type="submit" id="register" name="register">Regisztrált</button>
        </div>
        <div class="signup-link">Már be regisztrált? <a href="login.php"> Itt tud bejelentkezni</a></div>
      </form>
    </div>
  </div>