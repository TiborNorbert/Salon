<?php
include "minden/header.php";

$password1 = $password2 = "";
$email = $db->sanitizeData($_GET['email']);
isset($_GET['hash']) ? $hash = $db->sanitizeData($_GET['hash']) : $hash = "";
if (isset($_POST['new'])) {
    $password1 = $db->sanitizeData($_POST['password1']);
    $password2 = $db->sanitizeData($_POST['password2']);
    if ($password1 == $password2) {
        $password = password_hash($_POST['password1'], PASSWORD_DEFAULT);
        $sql = "UPDATE vevo SET jelszo='$password' WHERE email='$email' AND hash ='$hash';";
        echo $sql;
        $result = $db->RunSQL($sql);
        echo $result;
        if ($result > 0) {
            echo '<div class="alert alert-success text-center" role="alert">Az új jelszó be lett állítva! </div>';
            ?>
            <script>
                setTimeout(() => {
                    location.href = 'index.php';
                }, 3000);
            </script>
            <?php
        } else {
            echo '<div class="alert alert-warning text-center " role="alert">Hiba: A jelszó módosítás nem lehetséges!</div>';
        }
    } else {
        echo '<div class="alert alert-warning text-center" role="alert">A megadott jelszavak nem egyeznek meg! <br><b>Probáld meg újra!</b> </div>';
    }
}
?>


<div class="row">
    <main>
        <article class="d-flex flex-wrap" >
            <div class="col-6 offset-3 my-3">
                <div class="card mb-3 text-center h-100 mx-2">
                    <img class='card-img-top w-25 mx-auto '  src="img/user.png"  alt="...">
                    <div class="card-body">
                        <form method="POST" >
                            <div class="mb-3">
                                <label for="jelszo" class="form-label">Új jelszó</label>
                                <input type="password" class="form-control" id="jelszo" name="password1" id="password1" >
                            </div>
                            <div class="mb-3">
                                <label for="jelszo" class="form-label">Az új jelszó megerősítése</label>
                                <input type="password" class="form-control" id="jelszo"  name="password2" id="password2" >
                            </div>

                            <button type="submit" class="btn btn-secondary my-3" id="new" name="new" >Új jelszó beállítás</button>
                            <div class="d-flex justify-content-around" >
                                <a  class="" href="index.php" >Mégsem</button></a>
                            </div>
                        </form>
                    </div>

                </div>
            </div>

    </main>
</div>