<?php
include 'minden/header.php';
$sql1="SELECT `nev`,`ar` FROM `szolgaltatasok` WHERE `szolgaltatas`='masszazs'";
$result1 = $db->RunSQL($sql1);
$sql2="SELECT `nev`,`ar` FROM `szolgaltatasok` WHERE `szolgaltatas`='fodrasz'";
$result2 = $db->RunSQL($sql2);
$sql3="SELECT `nev`,`ar` FROM `szolgaltatasok` WHERE `szolgaltatas`='mukorom'";
$result3 = $db->RunSQL($sql3);
$sql4="SELECT `nev`,`ar` FROM `szolgaltatasok` WHERE `szolgaltatas`='kozmetika'";
$result4 = $db->RunSQL($sql4);
?>
<style>
    #masszazs,#fodrasz,#mukorom,#kozmetika{
    text-decoration: underline;}
</style>
<h1>Szolgáltatások</h1>
<table>
    <th id="masszazs">Masszázs</th>
    <th>Ár (Ft)</th>
    <?php foreach ($result1 as $sor):?>
        <tr>
            <?php foreach($sor as $cella):?>
            <td>
                <?php echo $cella?>
                </td>
<?php endforeach;?>
        </tr>
        <?php endforeach;?>
    <th id="fodrasz">Fodrász</th>
    <?php foreach ($result2 as $sor):?>
        <tr>
            <?php foreach($sor as $cella):?>
            <td>
                <?php echo $cella?>
            </td>
<?php endforeach;?>
        </tr>
        <?php endforeach;?>
    <th id="mukorom">Műköröm</th>
    <?php foreach ($result3 as $sor):?>
        <tr>
            <?php foreach($sor as $cella):?>
            <td>
                <?php echo $cella?>
            </td>
<?php endforeach;?>
        </tr>
        <?php endforeach;?>
    <th id=kozmetika>Kozmetika</th>
    <?php foreach ($result4 as $sor):?>
        <tr>
            <?php foreach($sor as $cella):?>
            <td>
                <?php echo $cella?>
            </td>
<?php endforeach;?>
        </tr>
        <?php endforeach;?> 
            </table>